import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useSpring, animated } from 'react-spring';
import axios from 'axios';

const Container = styled.div`
  background: linear-gradient(135deg, #f3ec78, #af4261);
  min-height: 100vh;
  padding: 20px;
  color: white;
  font-family: Arial, sans-serif;
`;

const Title = styled.h1`
  text-align: center;
  margin-bottom: 20px;
`;

const Form = styled.form`
  display: flex;
  justify-content: center;
  margin-bottom: 20px;

  & > input {
    padding: 10px;
    margin-right: 10px;
    border: none;
    border-radius: 4px;
  }

  & > button {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    background-color: #6a0572;
    color: white;
    cursor: pointer;
    transition: background-color 0.3s ease;

    &:hover {
      background-color: #a4067c;
    }
  }
`;

const Table = styled.table`
  width: 100%;
  margin-top: 20px;
  border-collapse: collapse;

  & th, & td {
    padding: 10px;
    border: 1px solid white;
    text-align: left;
  }

  & th {
    background-color: #6a0572;
  }
`;

const Button = styled.button`
  background-color: ${(props) => (props.delete ? '#e63946' : '#1d3557')};
  color: white;
  border: none;
  padding: 5px 10px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: ${(props) => (props.delete ? '#ff6b6b' : '#457b9d')};
  }
`;

const App = () => {
  const [bookName, setBookName] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [books, setBooks] = useState([]);
  const props = useSpring({ opacity: 1, from: { opacity: 0 } });

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/books');
      setBooks(response.data);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const handleAddBook = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/books', { bookName, authorName });
      fetchBooks();
      setBookName('');
      setAuthorName('');
    } catch (error) {
      console.error('Error adding book:', error);
    }
  };

  const handleDeleteBook = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/books/${id}`);
      fetchBooks();
    } catch (error) {
      console.error('Error deleting book:', error);
    }
  };

  const handleEditBook = (id) => {
    const book = books.find(book => book._id === id);
    setBookName(book.bookName);
    setAuthorName(book.authorName);
    handleDeleteBook(id);
  };

  return (
    <Container>
      <Title>Library Management</Title>
      <Form onSubmit={handleAddBook}>
        <input
          type="text"
          placeholder="Book Name"
          value={bookName}
          onChange={(e) => setBookName(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Author Name"
          value={authorName}
          onChange={(e) => setAuthorName(e.target.value)}
          required
        />
        <button type="submit">Add Book</button>
      </Form>
      <animated.div style={props}>
        <Table>
          <thead>
            <tr>
              <th>Book Name</th>
              <th>Author Name</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          {books.map((book) => (
            <tr key={book._id}>
              <td>{book.bookName}</td>
              <td>{book.authorName}</td>
              <td>
                <Button onClick={() => handleEditBook(book._id)}>Edit</Button>
                <Button delete onClick={() => handleDeleteBook(book._id)}>Delete</Button>
              </td>
            </tr>
          ))}
        </tbody>
        </Table>
      </animated.div>
    </Container>
  );
};

export default App;
